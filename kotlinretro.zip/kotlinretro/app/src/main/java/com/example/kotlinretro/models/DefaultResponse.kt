package com.example.kotlinretro.models
import com.google.gson.annotations.SerializedName
data class DefaultResponse(val error: Boolean, val message:String)